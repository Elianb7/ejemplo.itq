/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.itq.lenguajeProgramacion.DAO;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author PORTATIL
 */
@Entity
@Table(name = "cliente")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cliente.findAll", query = "SELECT c FROM Cliente c")})
public class Cliente implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_client")
    private int idClient;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "ced_cliente")
    private String cedCliente;
    @Size(max = 30)
    @Column(name = "nom_client")
    private String nomClient;
    @Size(max = 30)
    @Column(name = "ape_client")
    private String apeClient;
    @Size(max = 10)
    @Column(name = "telf_client")
    private String telfClient;
    @Size(max = 40)
    @Column(name = "direc_client")
    private String direcClient;
    @Size(max = 30)
    @Column(name = "correo_client")
    private String correoClient;
    @OneToMany(mappedBy = "cedCliente", fetch = FetchType.LAZY)
    private List<Factura> facturaList;

    public Cliente() {
    }

    public Cliente(String cedCliente) {
        this.cedCliente = cedCliente;
    }

    public Cliente(String cedCliente, int idClient) {
        this.cedCliente = cedCliente;
        this.idClient = idClient;
    }

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    public String getCedCliente() {
        return cedCliente;
    }

    public void setCedCliente(String cedCliente) {
        this.cedCliente = cedCliente;
    }

    public String getNomClient() {
        return nomClient;
    }

    public void setNomClient(String nomClient) {
        this.nomClient = nomClient;
    }

    public String getApeClient() {
        return apeClient;
    }

    public void setApeClient(String apeClient) {
        this.apeClient = apeClient;
    }

    public String getTelfClient() {
        return telfClient;
    }

    public void setTelfClient(String telfClient) {
        this.telfClient = telfClient;
    }

    public String getDirecClient() {
        return direcClient;
    }

    public void setDirecClient(String direcClient) {
        this.direcClient = direcClient;
    }

    public String getCorreoClient() {
        return correoClient;
    }

    public void setCorreoClient(String correoClient) {
        this.correoClient = correoClient;
    }

    @XmlTransient
    public List<Factura> getFacturaList() {
        return facturaList;
    }

    public void setFacturaList(List<Factura> facturaList) {
        this.facturaList = facturaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cedCliente != null ? cedCliente.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cliente)) {
            return false;
        }
        Cliente other = (Cliente) object;
        if ((this.cedCliente == null && other.cedCliente != null) || (this.cedCliente != null && !this.cedCliente.equals(other.cedCliente))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ec.edu.itq.lenguajeProgramacion.DAO.Cliente[ cedCliente=" + cedCliente + " ]";
    }
    
}
