/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.itq.lenguajeProgramacion.DAO;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author PORTATIL
 */
@Entity
@Table(name = "usuario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Usuario.findAll", query = "SELECT u FROM Usuario u")})
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cod_usu")
    private int codUsu;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "ced_us")
    private String cedUs;
    @Size(max = 30)
    @Column(name = "nom_us")
    private String nomUs;
    @Size(max = 30)
    @Column(name = "ape_usu")
    private String apeUsu;
    @Size(max = 30)
    @Column(name = "dire_usu")
    private String direUsu;
    @Size(max = 10)
    @Column(name = "telf_usu")
    private String telfUsu;
    @Size(max = 30)
    @Column(name = "tipo_usuario")
    private String tipoUsuario;
    @Size(max = 30)
    @Column(name = "contra_usu")
    private String contraUsu;

    public Usuario() {
    }

    public Usuario(String cedUs) {
        this.cedUs = cedUs;
    }

    public Usuario(String cedUs, int codUsu) {
        this.cedUs = cedUs;
        this.codUsu = codUsu;
    }

    public int getCodUsu() {
        return codUsu;
    }

    public void setCodUsu(int codUsu) {
        this.codUsu = codUsu;
    }

    public String getCedUs() {
        return cedUs;
    }

    public void setCedUs(String cedUs) {
        this.cedUs = cedUs;
    }

    public String getNomUs() {
        return nomUs;
    }

    public void setNomUs(String nomUs) {
        this.nomUs = nomUs;
    }

    public String getApeUsu() {
        return apeUsu;
    }

    public void setApeUsu(String apeUsu) {
        this.apeUsu = apeUsu;
    }

    public String getDireUsu() {
        return direUsu;
    }

    public void setDireUsu(String direUsu) {
        this.direUsu = direUsu;
    }

    public String getTelfUsu() {
        return telfUsu;
    }

    public void setTelfUsu(String telfUsu) {
        this.telfUsu = telfUsu;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    public String getContraUsu() {
        return contraUsu;
    }

    public void setContraUsu(String contraUsu) {
        this.contraUsu = contraUsu;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cedUs != null ? cedUs.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuario)) {
            return false;
        }
        Usuario other = (Usuario) object;
        if ((this.cedUs == null && other.cedUs != null) || (this.cedUs != null && !this.cedUs.equals(other.cedUs))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ec.edu.itq.lenguajeProgramacion.DAO.Usuario[ cedUs=" + cedUs + " ]";
    }
    
}
