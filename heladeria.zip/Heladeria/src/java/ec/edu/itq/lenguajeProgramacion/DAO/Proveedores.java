/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.itq.lenguajeProgramacion.DAO;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author PORTATIL
 */
@Entity
@Table(name = "proveedores")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Proveedores.findAll", query = "SELECT p FROM Proveedores p")})
public class Proveedores implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_pro")
    private int idPro;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "ced_pro")
    private String cedPro;
    @Size(max = 30)
    @Column(name = "nom_pro")
    private String nomPro;
    @Size(max = 30)
    @Column(name = "direc_pro")
    private String direcPro;
    @Size(max = 10)
    @Column(name = "telf_pro")
    private String telfPro;
    @Size(max = 30)
    @Column(name = "correo_pro")
    private String correoPro;

    public Proveedores() {
    }

    public Proveedores(String cedPro) {
        this.cedPro = cedPro;
    }

    public Proveedores(String cedPro, int idPro) {
        this.cedPro = cedPro;
        this.idPro = idPro;
    }

    public int getIdPro() {
        return idPro;
    }

    public void setIdPro(int idPro) {
        this.idPro = idPro;
    }

    public String getCedPro() {
        return cedPro;
    }

    public void setCedPro(String cedPro) {
        this.cedPro = cedPro;
    }

    public String getNomPro() {
        return nomPro;
    }

    public void setNomPro(String nomPro) {
        this.nomPro = nomPro;
    }

    public String getDirecPro() {
        return direcPro;
    }

    public void setDirecPro(String direcPro) {
        this.direcPro = direcPro;
    }

    public String getTelfPro() {
        return telfPro;
    }

    public void setTelfPro(String telfPro) {
        this.telfPro = telfPro;
    }

    public String getCorreoPro() {
        return correoPro;
    }

    public void setCorreoPro(String correoPro) {
        this.correoPro = correoPro;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cedPro != null ? cedPro.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Proveedores)) {
            return false;
        }
        Proveedores other = (Proveedores) object;
        if ((this.cedPro == null && other.cedPro != null) || (this.cedPro != null && !this.cedPro.equals(other.cedPro))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ec.edu.itq.lenguajeProgramacion.DAO.Proveedores[ cedPro=" + cedPro + " ]";
    }
    
}
