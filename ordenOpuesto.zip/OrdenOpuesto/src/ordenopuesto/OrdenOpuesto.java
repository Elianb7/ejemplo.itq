/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenopuesto;

import javax.swing.JOptionPane;

public class OrdenOpuesto {

    public static void main(String[] args) {
               int num1,num2,num3,num4,num5;
        
        num1=Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
        num2=Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
        num3=Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
        num4=Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
        num5=Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
        
        
            JOptionPane.showMessageDialog(null,"Imprimir"+num5+"-"+num4+"-"+num3+"-"+num2+"-"+num1);
        
    }
    
    
}
