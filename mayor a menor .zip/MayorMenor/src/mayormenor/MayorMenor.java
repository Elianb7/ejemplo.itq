/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayormenor;

import javax.swing.JOptionPane;

/**
 *
 * @author PORTATIL
 */
public class MayorMenor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num1,num2,num3;
        
        num1=Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
        num2=Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
        num3=Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero"));
        
        if((num1>num2)&&(num2>num3)){
            JOptionPane.showMessageDialog(null,"ordenar"+num1+"-"+num2+"-"+num3);
        }
               else if((num1>num3)&&(num3>num2)){
            JOptionPane.showMessageDialog(null,"ordenar"+num1+"-"+num3+"-"+num2);
        }
               else if((num2>num1)&&(num1>num3)){
            JOptionPane.showMessageDialog(null,"ordenar"+num2+"-"+num1+"-"+num3);
        }
                     else   if((num1>num3)&&(num3>num1)){
            JOptionPane.showMessageDialog(null,"ordenar"+num2+"-"+num3+"-"+num2);
        }
                           else     if((num3>num1)&&(num1>num2)){
            JOptionPane.showMessageDialog(null,"ordenar"+num3+"-"+num1+"-"+num2);
        }
                                   else    {
            JOptionPane.showMessageDialog(null,"ordenar"+num3+"-"+num2+"-"+num1);
        }
    }
    
}
